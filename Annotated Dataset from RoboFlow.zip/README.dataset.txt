# Allianz Project > 2023-10-12 11:22am
https://universe.roboflow.com/test-rsvge/allianz-project

Provided by a Roboflow user
License: CC BY 4.0

